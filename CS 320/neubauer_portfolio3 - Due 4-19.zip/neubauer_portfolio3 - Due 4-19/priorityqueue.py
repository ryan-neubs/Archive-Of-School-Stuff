# priorityqueue.py

class PriorityQueue:

    def __init__(Self, items=[]):
        self.heap = list(items)
        self._build_heap()

    def _largest_child(self, i):
        pass

    def _bubble_up(self, i):
        pass

    def _bubble_down(self, i):
        pass

    def _build_heap(self):
        pass

    def add(self, item):
        pass

    def get_max(self):
        pass