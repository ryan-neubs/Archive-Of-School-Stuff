Portfolio Due 2/11/2022
Ryan Neubauer

Directories/What is in them:

Misc Algorithms - Consists of Euclid's algorithm and an algorthm to return common items from a list. These were just programs I was tinkering with to allow me better visualize the algorithms.
Euclid's algorithm is complete and simplified the best I believe it can be, but the common items one is definitely not opitimized or written well. Common items has a lot of hidden steps in it.

Sieve - Holds the Sieve.py program. Program works well and implements the Sieve algorithm into python. The program prompts the use for an input of size n and allows them to try different sizes
till they want to quit.

Sorting Algorithms - This contains 4 files: BubbleSort.py, CompareCountSort.py, SelectionSort.py, and multisorter.py. All algorithms work properly and upon running the programs the user can create a
list for testing. User can enter list length, adjust the range of the values within the list, and finally enter the amount of trials to run on the algorithm.
In multisorter.py, the user can follow the same process but use the list on all (or some) of the algorithms. The program will then return the average time of each algorithm for the user to compare.

RandomList.py - This is just a program that creates an entirely random list that I used for testing to make sure the code worked. Just made the process of compiling and debugging faster.
