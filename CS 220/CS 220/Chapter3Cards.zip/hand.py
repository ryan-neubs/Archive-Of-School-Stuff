# hand.py

class Hand:
    """A labeled collection of cards that can be sorted"""

    def __init__(self, label=""):
        """Create an empty collection with the given label."""

        self.label = label
        self.cards = []

    def add(self, card):
        """ Add card to the hand """

        self.cards.append(card)

    def sort(self):
        """ Arrange the cards in descending bridge order."""

        self.cards.sort()
        self.cards.reverse()

    def dump(self):
        """ Print out contents of the Hand."""

        print(self.label + "'s Cards:")
        for c in self.cards:
            print("   ", c)

    #----------------------------------------------------------
    # These are just example methods of the sort you may want
    #    to use in order to complete the program
    
    def rankPoints(self):
        """ return number of points for high rank cards """

    def suitCount(self, suit):
        """ return number of cards of the given suit """

    def suitPoints(self):
        """ return points for short suits """

    def totalPoints(self):
        """ return total hand points (rankPoints + suitsPoints) """

    def hasHonor(self, suit):
        """ return whether hand has a face card (including ace) in suit """

    def hasBiddibleSuit(self):
        """ return whether hand contains a biddable suit """

    def canOpen(self):
        """return whether the hand can open"""
