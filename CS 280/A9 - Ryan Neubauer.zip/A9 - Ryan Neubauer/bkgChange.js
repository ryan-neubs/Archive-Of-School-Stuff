//bkgChange
function bkgChange(bkg, color) {
	if (bkg=="top") {
		document.body.style.backgroundColor = color;
	}
	else {
		document.body.style.color = color;
	}
}