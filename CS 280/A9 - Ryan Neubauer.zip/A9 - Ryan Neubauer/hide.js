function hide(imageName) {
  var x = document.getElementById(imageName);
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}