# pi.py
# this program estimates the digits of pi
# by Ryan Neubauer
sgn = 1
total = 0
n = int(input("Enter a positive integer for n: "))
for denom in range(1,2*n,2):
    term = sgn*4/denom
    total = total + term
    sgn = sgn * (-1)
    print(total)

